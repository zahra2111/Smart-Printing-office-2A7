#include "materiel.h"
#include <QDebug>

materiel::materiel(int nbr_de_piece,int reference,QString nom_materiel,QString date_maintenance)
{
    this->reference=reference;
    this->nbr_de_piece=nbr_de_piece;
    this->nom_materiel=nom_materiel;
    this->date_maintenance=date_maintenance;
}
bool materiel::ajouter()
{
    QSqlQuery query;
    QString res = QString::number(reference);
    QString res2 = QString::number(nbr_de_piece);
    qDebug() << date_maintenance;
    query.prepare("insert into materiel (reference,nom_materiel,nbr_de_piece,date_maintenance) ""values(:reference,:nom_materiel,:nbr_de_piece,TO_DATE(:date_maintenance,'DD-MM-YYYY'))");
   query.bindValue(":reference",res);
   query.bindValue(":nom_materiel",nom_materiel);
   query.bindValue(":nbr_de_piece",res2);
   query.bindValue(":date_maintenance",date_maintenance);
   return query.exec();
}
QSqlQueryModel * materiel::afficher(QString rech, int ord)
{
QSqlQueryModel * model=new QSqlQueryModel();
model->setQuery("select * from materiel where lower(nom_materiel) LIKE lower('%" + rech + "%')");
model->setHeaderData(0,Qt::Horizontal,QObject::tr("REFERENCE"));

model->setHeaderData(1,Qt::Horizontal,QObject::tr("NBR_DE_PIECE"));

model->setHeaderData(2,Qt::Horizontal,QObject::tr("NOM_MATERIEL"));

model->setHeaderData(3,Qt::Horizontal,QObject::tr("DATE_MAINTENANCE"));
model->setHeaderData(4,Qt::Horizontal,QObject::tr("DATE_ACHAT"));
return model;
}
bool materiel::supprimer(int reference)
{
QSqlQuery query;
QString res = QString::number(reference);
query.prepare("Delete from materiel where reference= :reference");
query.bindValue(":reference",res);
return query.exec();
}




bool materiel::modify(int reference){
    QSqlQuery query;
    query.prepare("UPDATE MATERIEL SET nom_materiel=:nom_materiel, nbr_de_piece=:nbr_de_piece, date_maintenance=TO_DATE(:date_maintenance,'DD-MM-YYYY'),  date_achat=TO_DATE(:date_achat,'DD-MM-YYYY') WHERE reference=:reference");
    query.bindValue(":reference",reference);
    query.bindValue(":nom_materiel",nom_materiel);
    query.bindValue(":nbr_de_piece",nbr_de_piece);
    query.bindValue(":date_maintenance",date_maintenance);
    query.bindValue(":date_achat",date_achat);
    return query.exec();
}



QSqlQueryModel * materiel::show_Desc_name()
{
    QSqlQueryModel* model = new QSqlQueryModel();
     model->setQuery("select * from MATERIEL ORDER BY NOM_MATERIEL ASC ");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("REFERENCE"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("NBR_DE_PIECE"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOM_MATERIEL"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("DATE_MAINTENANCE"));
     model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_ACHAT"));
     return model;
}

QSqlQueryModel * materiel::show_Desc_ref()
{
    QSqlQueryModel* model = new QSqlQueryModel();
     model->setQuery("select * from MATERIEL ORDER BY REFERENCE ASC ");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("REFERENCE"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("NBR_DE_PIECE"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOM_MATERIEL"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("DATE_MAINTENANCE"));
     model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_ACHAT"));
     return model;
}

QSqlQueryModel * materiel::show_Desc_number()
{
    QSqlQueryModel* model = new QSqlQueryModel();
     model->setQuery("select * from MATERIEL ORDER BY NBR_DE_PIECE ASC ");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("REFERENCE"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("NBR_DE_PIECE"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOM_MATERIEL"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("DATE_MAINTENANCE"));
     model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_ACHAT"));
     return model;
}




