#include "mainwindow.h"
#include "profils.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include "TailButtonsDelegate.h"
#include <QMessageBox>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(2);

    ui->tableView->setEditTriggers(QTableView::AllEditTriggers);
    ui->tableView->setSelectionBehavior(QTableView::SelectRows);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setItemDelegateForColumn(4,new TailButtonsDelegate(ui->tableView));


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    qDebug() << "pushed";
    ui->tableView->setModel(mat.afficher(ui->lineEditAff->text(), 0));
    ui->tableView->setItemDelegateForColumn(4,new TailButtonsDelegate(ui->tableView));


}





void MainWindow::on_lineEditAff_textEdited(const QString &arg1)
{
    ui->tableView->setModel(mat.afficher(ui->lineEditAff->text(), 0));

}

void MainWindow::on_lineEditAff_textChanged(const QString &arg1)
{
    ui->tableView->setModel(mat.afficher(ui->lineEditAff->text(), 0));
    ui->tableView->setItemDelegateForColumn(4,new TailButtonsDelegate(ui->tableView));


}

void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{
    ui->tableView->setModel(mat.afficher(ui->lineEditAff->text(), 0));

}


void MainWindow::on_Ajouteraff_clicked()
{
    //ui->stackedWidget->setCurrentIndex(2);

    ui->le_login->setText("");
    ui->le_password->setText("");

    requireLogin(0);

}

void MainWindow::on_annulerajout_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_quitterajout_clicked()
{
    QCoreApplication::quit();
}

void MainWindow::on_confirmerajout_clicked()
{
    materiel * nmat = new materiel(ui->nombreajout->text().toInt(), ui->refajout->text().toInt(), ui->nomajout->text(), ui->dateajout->dateTime().toString("dd-MM-yyyy"));
    nmat->ajouter();
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_Quitteraff_clicked()
{
    QCoreApplication::quit();

}

void MainWindow::on_quittermodif_clicked()
{
    QCoreApplication::quit();

}

void MainWindow::on_annulermodif_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_tableView_clicked(const QModelIndex &indexx)
{

    QPoint mousePos = QCursor::pos();
    QPoint localPos = ui->tableView->mapFromGlobal( mousePos );
    qDebug() << " mouse positions  global= " << mousePos << "local = " << localPos;
    QModelIndex index=ui->tableView->selectionModel()->currentIndex();
    QVariant value=index.sibling(index.row(),0).data();
    if(localPos.x()<675)return;
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Suppression", "Effacer?",
                                  QMessageBox::Yes|QMessageBox::No);


    if (reply == QMessageBox::Yes) {

        mat.supprimer(value.toInt());

        ui->tableView->setModel(mat.afficher(ui->lineEditAff->text(), 0));
        ui->tableView->setItemDelegateForColumn(4,new TailButtonsDelegate(ui->tableView));

    } else {

    }
}

void MainWindow::on_stackedWidget_currentChanged(int arg1)
{

    if(arg1==3)
    {
        ui->tableView->setModel(mat.afficher("", 0));
    }else if(arg1==1)
    {
        QModelIndex index=ui->tableView->selectionModel()->currentIndex();
        QVariant value=index.sibling(index.row(),0).data();
        mref = value.toInt();

        value=index.sibling(index.row(),1).data();
        ui->nombremodif->setText(value.toString());


        value = index.sibling(index.row(), 2).data();
        ui->nommodif->setText(value.toString());

        value = index.sibling(index.row(), 3).data();
        ui->datemodif->setDate(value.toDate());

        value = index.sibling(index.row(), 4).data();
        ui->achatmodif->setDate(value.toDate());



    }

}

void MainWindow::on_Ajouteraff_2_clicked()
{

    ui->le_login->setText("");
    ui->le_password->setText("");

    requireLogin(1);


}

void MainWindow::requireLogin(int ns)
{
    nextScene = ns;
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_confirmermodif_clicked()
{
    materiel * tmat = new materiel(ui->nombremodif->text().toInt(), mref, ui->nommodif->text(), ui->datemodif->date().toString("dd-MM-yyyy"));
    tmat->date_achat = ui->achatmodif->date().toString("dd-MM-yyyy");
    tmat->modify(mref);
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pb_login_clicked()
{

  QString login = ui->le_login->text();
  QString password = ui->le_password->text();
  if(P.login(login, password)) {

           ui->stackedWidget->setCurrentIndex(nextScene);

  }
  else {
      QMessageBox::critical(nullptr, QObject::tr("LOGIN FAILED"),
                  QObject::tr("Check your login and password!\n"), QMessageBox::Cancel);
  }

}

void MainWindow::on_quitterlogin_clicked()
{
    QCoreApplication::quit();

}

void MainWindow::on_Ajouteraff_3_clicked()
{
    ui->tableView->setModel(mat.show_Desc_ref());
}

void MainWindow::on_Ajouteraff_5_clicked()
{
    ui->tableView->setModel(mat.show_Desc_number());
}

void MainWindow::on_Ajouteraff_4_clicked()
{
    ui->tableView->setModel(mat.show_Desc_name());
}
