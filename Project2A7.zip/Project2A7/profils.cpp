#include "profils.h"

#include<QSqlQuery>
#include<QtDebug>
#include<QObject>

Profils::Profils()
{

LOGIN="";
MOT_DE_PASSE="";
}
Profils::Profils(QString LOGIN ,QString MOT_DE_PASSE, int id)
{this->LOGIN=LOGIN;
this->MOT_DE_PASSE=MOT_DE_PASSE;
    this->id_e = id;
}

QString Profils::getlogin(){return LOGIN;}

QString Profils::getmot_de_passe(){return MOT_DE_PASSE;}



void Profils::setlogin(QString LOGIN){this->LOGIN=LOGIN;}
 void Profils::setmot_de_passe(QString MOT_DE_PASSE) {this->MOT_DE_PASSE=MOT_DE_PASSE;}

 bool Profils::login(QString l, QString p) {
     QSqlQuery query;
     query.prepare("SELECT login, password, id_e FROM PROFILS WHERE login = ? AND password = ?");
     query.addBindValue(l);
     query.addBindValue(p);
     query.exec();
     while(query.next()){
         if(query.value(0).toString() == l && query.value(1).toString() == p) {
             this->LOGIN = query.value(0).toString();
             this->MOT_DE_PASSE = query.value(1).toString();
             this->id_e = query.value(2).toInt();
             return true;
         }
     }
     return false;
 }
