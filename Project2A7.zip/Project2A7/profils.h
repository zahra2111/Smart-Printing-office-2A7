#ifndef PROFILS_H
#define PROFILS_H
#include<QDate>
#include<QString>
#include<QSqlQueryModel>
#include <QComboBox>


class Profils
{
public:
    Profils();
Profils(QString,QString, int);
    //getter

    QString getlogin();
    QString getmot_de_passe();

      //setter
    void setlogin(QString);
    void setmot_de_passe(QString);
    //method
    bool login(QString, QString);

private:

    QString LOGIN;
   QString MOT_DE_PASSE;
   int id_e;
};

#endif // PROFILS_H



