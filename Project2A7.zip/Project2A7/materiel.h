#ifndef MATERIEL_H
#define MATERIEL_H
#include <QString>
#include<QSqlQuery>
#include<QSqlQueryModel>

class materiel
{
 int nbr_de_piece,reference;
 QString nom_materiel,date_maintenance;
public:
 QString date_achat;
 materiel(){}
 materiel(int,int,QString,QString);
 int getreference(){return reference;}
 int getnbr_de_piece(){return nbr_de_piece;}
 QString getnom_materiel(){return nom_materiel;}
 QString getdate_maintenance(){return date_maintenance;}
 void setreference(int id){this->reference=id;}
 void setnbr_de_piece(int nb){this->nbr_de_piece=nb;}
 void setnom_materiel(QString nm){nom_materiel=nm;}
 void setdate_maintenance(QString de){date_maintenance=de;}
 bool ajouter();
 QSqlQueryModel * afficher(QString, int);
 bool supprimer(int);
 bool modify(int);
 QSqlQueryModel * show_Desc_name();
 QSqlQueryModel * show_Desc_ref();
 QSqlQueryModel * show_Desc_number();
};

#endif // MATERIEL_H
